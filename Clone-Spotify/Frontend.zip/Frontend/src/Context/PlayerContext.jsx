const url = 'http://localhost:5001'

const getAlbumsData = async () => {
  try {
    const res = await axios.get(`${url}/api/album/list`)
    setAlbumsData(res.data.albums)
  } catch (error) {
    console.log('error getAlbumsData', error)
  }
}

useEffect(() => {
  getAlbumsData()
  getSongsData()
}, [])
