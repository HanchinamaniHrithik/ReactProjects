import { useContext } from 'react'
import Display from './components/Display'
import Player from './Components/player'
import Sidebar from './components/Sidebar'
import { PlayerContext } from './context/PlayerContext'

const App = () => {
  const { audioRef, track, songsData } = useContext(PlayerContext)
  console.log('songsData:', songsData)
  return (
    <div className='h-screen bg-black text-white'>
      <div className='h-[90%] flex'>
        <Sidebar />
        <Display />
      </div>
      <Player />
    </div>
  )
}

export default App
