import React, { useContext } from 'react'
import { assets } from '../assets/assets'
import { PlayerContext } from '../context/PlayerContext'

const Player = () => {
  const { track } = useContext(PlayerContext)

  return (
    <div className='h-[10%] bg-black flex justify-between items-center text-white px-4'>
      {track && (
        <div className='hidden lg:flex items-center gap-4'>
          <img className='w-12' src={track.image} alt='song img' />
          <div>
            <p>{track.name}</p>
            <p>{track.desc?.slice(0, 12)}</p>
          </div>
        </div>
      )}
    </div>
  )
}

export default Player
