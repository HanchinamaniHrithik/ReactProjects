import { useContext } from 'react'
import { PlayerContext } from '../Context/PlayerContext'
import { useParams } from 'react-router-dom'

const DisplayAlbum = () => {
  const { songsData, playWithId } = useContext(PlayerContext)
  const { id } = useParams()

  const albumSongs = songsData.filter((song) => song.album === id)

  return (
    <div className='text-white'>
      <h1 className='text-2xl font-bold mb-4'>Songs in this Album</h1>
      {albumSongs.length === 0 && <p>No songs found for this album.</p>}
      <ul className='space-y-4'>
        {albumSongs.map((song) => (
          <li
            key={song._id}
            className='flex items-center gap-4 bg-[#1e1e1e] p-4 rounded-lg hover:bg-[#2e2e2e] cursor-pointer'
            onClick={() => playWithId(song._id)}
          >
            <img
              src={song.image}
              alt={song.name}
              className='w-16 h-16 object-cover rounded'
            />
            <div>
              <p className='text-lg font-semibold'>{song.name}</p>
              <p className='text-sm text-gray-400'>{song.desc}</p>
            </div>
          </li>
        ))}
      </ul>
    </div>
  )
}

export default DisplayAlbum
